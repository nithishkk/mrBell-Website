import React from 'react';
import './App.scss';
import SideBar from "./Pages/SideBar"
import NavBar from './Pages/NavBar';

function App() {
  return (
    <div >
       <SideBar/>
       {/* <NavBar/> */}

    </div>
  );
}

export default App;
