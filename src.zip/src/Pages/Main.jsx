import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';

import Title from "../Images/MC-logo-final_MC-logo-horizontal.svg";
import Name from "../Images/WhatsApp Image 2024-03-11 at 8.25.45 PM.jpeg";
import NameTitle from "../Images/Yellow Did you know interesting fact Instagram post.png"

function Main() {
  const [searchTerm, setSearchTerm] = useState('');
  const handleInputChange = (e) => {
    setSearchTerm(e.target.value);
  };

  return (
    <div className="container">
    
      <div className="left-side">
        <h1>Murthy Chat</h1>
        <p className='Chart_oom'>Chat Room</p>
        <textarea
          value={searchTerm}
          onChange={handleInputChange}
          placeholder="Search..."
          className="search-input"
          rows={4}
          cols={50}
          />
        <p className='SearchName'>{searchTerm}</p>
      </div>

      <div className="right-side">
      <h1 className='Label_Name'>Village Radio</h1>
      <img src={NameTitle} alt="name" className='name_img'/>
      <div className='Links'>
          <Link to="/terms-and-condition">Terms and Condition</Link>
          <Link to="/privacy-policy">Privacy Policy</Link>
          <Link to="/community-standards">Community Standards</Link>
        </div>

      </div>
     
     
    </div>
  );
}

export default Main;



// import TermsAndCondition from './Pages/TermsAndCondition'
// import CommunityStandards from './Pages/CommunityStandards'

// export default function App() {
//   return (
//     <>
   
//       <Routes>
//       <Route path="/" element={<Main/>} />
//           <Route path="/terms-and-condition" element={<TermsAndCondition />} />
//           <Route path="/privacy-policy" element={<PrivacyPolicy />} />
//           <Route path="/community-standards" element={<CommunityStandards />} />
//         </Routes>
//     </>
//   )
// }
